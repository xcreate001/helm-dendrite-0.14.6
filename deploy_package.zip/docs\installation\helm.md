---
title: Helm
parent: Installation
has_children: true
nav_order: 3
permalink: /helm
---

# Helm

This section contains documentation how to use [Helm](https://helm.sh/) to install Dendrite on a [Kubernetes](https://kubernetes.io/) cluster.
