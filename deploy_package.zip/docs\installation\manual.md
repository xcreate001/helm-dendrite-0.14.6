---
title: Manual
parent: Installation
has_children: true
nav_order: 5
permalink: /manual
---

# Manual Installation

This section contains documentation how to manually install Dendrite
