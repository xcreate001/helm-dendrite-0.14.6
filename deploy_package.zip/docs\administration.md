---
title: Administration
has_children: yes
nav_order: 4
permalink: /administration
---

# Administration

This section contains documentation on managing your existing Dendrite deployment.
