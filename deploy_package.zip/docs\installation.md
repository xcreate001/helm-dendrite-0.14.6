---
title: Installation
has_children: true
nav_order: 2
permalink: /installation
---

# Installation

This section contains documentation on installing a new Dendrite deployment.
