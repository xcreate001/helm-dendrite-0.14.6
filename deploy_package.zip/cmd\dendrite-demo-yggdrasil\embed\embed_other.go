//go:build !elementweb
// +build !elementweb

package embed

import "github.com/gorilla/mux"

func Embed(_ *mux.Router, _ int, _ string) {

}
