---
title: Docker
parent: Installation
has_children: true
nav_order: 4
permalink: /docker
---

# Installation using Docker

This section contains documentation how to install Dendrite using Docker
